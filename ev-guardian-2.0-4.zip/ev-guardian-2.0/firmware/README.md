# Firmware (ESP32, Arduino framework)

🚧 **Under development.** Planned development stages:

| Stage | Target work |
|---|---|
| Week 1 | Finalize architecture, enclosure, sensor interfaces, safety boundaries |
| Week 2 | ESP32 acquisition and local / dashboard visualization |
| Week 3 | Diagnostic rules, Safety Score, fault localization |
| Week 4 | Protection outputs, Safety Black Box, Safe-Drive Interlock |
| Week 5+ | Edge anomaly model, repeatable validation scenarios, UI refinement |

Design outline: see [`../docs/pseudocode.md`](../docs/pseudocode.md).

Planned libraries: `OneWire` + `DallasTemperature` (DS18B20), `Adafruit_INA219`, an SSD1306 OLED library, and `SD`.

Do not commit Wi-Fi credentials — keep them in `secrets.h` (already git-ignored).
